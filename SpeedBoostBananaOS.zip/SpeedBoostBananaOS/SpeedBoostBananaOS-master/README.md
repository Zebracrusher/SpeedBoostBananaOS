# Super Monke
who remembers WristMenu?
# How to use
Hold B is fly

Hold A is ZeroG
# Requirments
Utilla

BananaOS
# Credits
Thanks to Veloc1ty for teaching me ho to make this!
