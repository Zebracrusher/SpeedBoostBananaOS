﻿using System;
using System.Text;
using UnityEngine;
using BepInEx;
using BananaOS;

namespace QuickDisconnectBananaOS
{
    [BepInPlugin("com.Estatic.SpeedBoost","SpeeBoost","1.0.0")]
    public class Class1 : BaseUnityPlugin
    {
        
    }
}
